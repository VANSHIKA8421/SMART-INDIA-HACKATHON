<?php
session_destroy();
header('Location: courier_login.html');
?>