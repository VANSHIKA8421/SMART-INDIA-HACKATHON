<?php
session_destroy();
header('Location: customer_login.html');
?>