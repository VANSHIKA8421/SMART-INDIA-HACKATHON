<?php
session_destroy();
header('Location: farmer_login.html');
?>
